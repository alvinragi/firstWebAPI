﻿using DatabaseLinkingTest1.Data;
using DatabaseLinkingTest1.Models;
using Microsoft.EntityFrameworkCore;

namespace DatabaseLinkingTest1.Data         //cs for interacting with database
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)     //constructors  //pass configuration options
        {
        }
        public DbSet<User> Users { get; set; }  //represent a collection of user entities from the database
    }
}



/*AppDbContext serves as the bridge between your application and the database, providing access to entities (such as User) 
 * through properties like Users.
 
The DbContextOptions passed to the constructor typically contain database connection information and other configurations needed 
by Entity Framework Core to connect to and interact with the database.

DbSet<User> represents a collection of User entities, allowing CRUD (Create, Read, Update, Delete) operations to be performed on the 
User table or collection in the connected database.

With this setup, Entity Framework Core will use AppDbContext to create, query, update, and delete User entities in the associated 
database based on the configured DbContextOptions and entity mappings.*/