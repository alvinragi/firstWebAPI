﻿using System.ComponentModel.DataAnnotations;

namespace DatabaseLinkingTest1.Models
{
    public class User
    {
        [Key]               //for defining the primary key thott below
        public int User_Id { get; set; }
        public string? Name { get; set; }
        public int Age { get; set; }
        public string? Role { get; set; }
    }
}
