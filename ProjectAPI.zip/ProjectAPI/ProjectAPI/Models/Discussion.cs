﻿namespace ProjectAPI.Models
{
    public class Discussion
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        // Other properties and relationships
    }
}