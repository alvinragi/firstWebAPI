﻿namespace ProjectAPI.Models
{
    public class User
    {
        public int Id { get; set; }
        public string? UserName { get; set; }
        public int UserAge { get; set; }
        public string? UserRole { get; set; }
    }
}
