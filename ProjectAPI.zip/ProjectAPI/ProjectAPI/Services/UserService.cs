﻿namespace ProjectAPI.Services
{
    using ProjectAPI.Models;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class UserService : IUserService
    {
        private readonly List<User> _users;

        public UserService()
        {
            _users = new List<User>
            {
                new User { Id = 1, UserName = "JohnDoe", UserAge = 29, UserRole = "Dev"},
                new User { Id = 2, UserName = "JaneSmith", UserAge = 24, UserRole = "BA"},
                new User { Id = 3, UserName = "Varkey", UserAge = 22, UserRole = "DA"}
            };
        }

        public async Task<IEnumerable<User>> GetUsersAsync()
        {
            return await Task.FromResult(_users);
        }

        public async Task<User> GetUserByIdAsync(int id)
        {
            return await Task.FromResult(_users.FirstOrDefault(u => u.Id == id));
        }

        public async Task AddUserAsync(User user)
        {
            user.Id = _users.Count + 1;
            _users.Add(user);
            await Task.CompletedTask;
        }

        public async Task UpdateUserAsync(int id, User user)
        {
            var existingUser = _users.FirstOrDefault(u => u.Id == id);
            if (existingUser != null)
            {
                existingUser.UserName = user.UserName;
                existingUser.UserAge = user.UserAge;
                existingUser.UserRole = user.UserRole;
            }
            await Task.CompletedTask;
        }

        public async Task DeleteUserAsync(int id)
        {
            var userToRemove = _users.FirstOrDefault(u => u.Id == id);
            if (userToRemove != null)
            {
                _users.Remove(userToRemove);
            }
            await Task.CompletedTask;
        }
    }
}

