﻿namespace ProjectAPI.Services
{
    using ProjectAPI.Models;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class DiscussionService : IDiscussionService
    {
        private readonly List<Discussion> _discussions;

        public DiscussionService()
        {
            _discussions = new List<Discussion>
            {
                new Discussion { Id = 1, Title = "First Discussion", Description = "Description for the first discussion" },
                new Discussion { Id = 2, Title = "Second Discussion", Description = "Description for the second discussion" },
            };
        }

        public async Task<IEnumerable<Discussion>> GetDiscussionsAsync()
        {
            return await Task.FromResult(_discussions);
        }

        public async Task<Discussion> GetDiscussionByIdAsync(int id)
        {
            return await Task.FromResult(_discussions.FirstOrDefault(d => d.Id == id));
        }

        public async Task AddDiscussionAsync(Discussion discussion)
        {
            discussion.Id = _discussions.Count + 1;
            _discussions.Add(discussion);
            await Task.CompletedTask;
        }

        public async Task UpdateDiscussionAsync(int id, Discussion discussion)
        {
            var existingDiscussion = _discussions.FirstOrDefault(d => d.Id == id);
            if (existingDiscussion != null)
            {
                existingDiscussion.Title = discussion.Title;
                existingDiscussion.Description = discussion.Description;
                // Update other properties if needed
            }
            await Task.CompletedTask;
        }

        public async Task DeleteDiscussionAsync(int id)
        {
            var discussionToRemove = _discussions.FirstOrDefault(d => d.Id == id);
            if (discussionToRemove != null)
            {
                _discussions.Remove(discussionToRemove);
            }
            await Task.CompletedTask;
        }
    }
}