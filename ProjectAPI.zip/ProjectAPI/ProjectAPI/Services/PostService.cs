﻿using ProjectAPI.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.Services
{
    public class PostService : IPostService
    {
        private readonly List<Post> _posts;

        public PostService()
        {
            _posts = new List<Post>
            {
                new Post { Id = 1, Content = "First Post" },
                new Post { Id = 2, Content = "Second Post" }
                // You can add more initial posts as needed
            };
        }

        public async Task<IEnumerable<Post>> GetPostsAsync()
        {
            return await Task.FromResult(_posts);
        }

        public async Task<Post> GetPostByIdAsync(int id)
        {
            return await Task.FromResult(_posts.FirstOrDefault(p => p.Id == id));
        }

        public async Task AddPostAsync()
        {            
                Post post = new Post();
                post.Id = _posts.Count + 1;
                post.Content = "New post";
                _posts.Add(post);
                await Task.CompletedTask;            
        }

        public async Task UpdatePostAsync(int id, Post updatedPost)
        {
            var existingPost = _posts.FirstOrDefault(p => p.Id == id);
            if (existingPost != null)
            {
                existingPost.Content = updatedPost.Content;
                // Update other properties if needed
            }
            await Task.CompletedTask;
        }


        public async Task DeletePostAsync(int id)
        {
            var postToRemove = _posts.FirstOrDefault(p => p.Id == id);
            if (postToRemove != null)
            {
                _posts.Remove(postToRemove);
            }
            await Task.CompletedTask;
        }
    }
}