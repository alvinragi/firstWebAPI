﻿using Microsoft.AspNetCore.Mvc;
using ProjectAPI.Models;
using ProjectAPI.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjectAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DiscussionController : ControllerBase
    {
        private readonly IDiscussionService _discussionService;

        public DiscussionController(IDiscussionService discussionService)
        {
            _discussionService = discussionService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Discussion>>> GetDiscussions()
        {
            var discussions = await _discussionService.GetDiscussionsAsync();
            return Ok(discussions);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Discussion>> GetDiscussionById(int id)
        {
            var discussion = await _discussionService.GetDiscussionByIdAsync(id);
            if (discussion == null)
            {
                return NotFound();
            }
            return Ok(discussion);
        }

        [HttpPost]
        public async Task<ActionResult<Discussion>> AddDiscussion(Discussion discussion)
        {
            await _discussionService.AddDiscussionAsync(discussion);
            return CreatedAtAction(nameof(GetDiscussionById), new { id = discussion.Id }, discussion);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDiscussion(int id, Discussion discussion)
        {
            if (id != discussion.Id)
            {
                return BadRequest();
            }

            await _discussionService.UpdateDiscussionAsync(id, discussion);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDiscussion(int id)
        {
            await _discussionService.DeleteDiscussionAsync(id);
            return NoContent();
        }
    }
}