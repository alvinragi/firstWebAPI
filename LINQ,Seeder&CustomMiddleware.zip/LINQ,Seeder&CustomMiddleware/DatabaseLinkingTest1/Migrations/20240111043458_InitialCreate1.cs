﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DatabaseLinkingTest1.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 10, 4, 57, 920, DateTimeKind.Local).AddTicks(9242));

            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 10, 4, 57, 920, DateTimeKind.Local).AddTicks(9251));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 9, 52, 6, 531, DateTimeKind.Local).AddTicks(1734));

            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 9, 52, 6, 531, DateTimeKind.Local).AddTicks(1745));
        }
    }
}
