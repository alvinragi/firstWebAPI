﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DatabaseLinkingTest1.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 10, 10, 17, 309, DateTimeKind.Local).AddTicks(986));

            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 10, 10, 17, 309, DateTimeKind.Local).AddTicks(998));

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 1,
                column: "Name",
                value: "Tootu Doe");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 10, 4, 57, 920, DateTimeKind.Local).AddTicks(9242));

            migrationBuilder.UpdateData(
                table: "Discussions",
                keyColumn: "DiscussionID",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2024, 1, 11, 10, 4, 57, 920, DateTimeKind.Local).AddTicks(9251));

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 1,
                column: "Name",
                value: "John Doe");
        }
    }
}
