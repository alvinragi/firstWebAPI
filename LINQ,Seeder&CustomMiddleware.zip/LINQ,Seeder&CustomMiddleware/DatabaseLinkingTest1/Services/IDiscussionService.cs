﻿using DatabaseLinkingTest1.Models;

namespace DatabaseLinkingTest1.Services
{
    public interface IDiscussionService
    {
        Task<IEnumerable<Discussion>> GetDiscussionsAsync();
        Task<Discussion> GetDiscussionByIdAsync(int id);
        Task AddDiscussionAsync(Discussion discussion);
        Task UpdateDiscussionAsync(int id, Discussion discussion);
        Task DeleteDiscussionAsync(int id);
    }
}
