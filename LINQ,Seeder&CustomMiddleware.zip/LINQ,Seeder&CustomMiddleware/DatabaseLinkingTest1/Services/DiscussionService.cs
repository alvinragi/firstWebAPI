﻿using DatabaseLinkingTest1.Models;
using DatabaseLinkingTest1.Data;
using Microsoft.EntityFrameworkCore;

namespace DatabaseLinkingTest1.Services
{
    public class DiscussionService : IDiscussionService
    {
        private readonly AppDbContext _context;

        public DiscussionService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Discussion>> GetDiscussionsAsync()
        {
            return await _context.Discussions.Include(u => u.User).ToListAsync();// LAZY LOADING. to include the table values of discussion which is mapped.
        }

        public async Task<Discussion> GetDiscussionByIdAsync(int id)
        {
            return await _context.Discussions.FindAsync(id);
        }

        public async Task AddDiscussionAsync(Discussion discussion)
        {
            _context.Discussions.Add(discussion);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateDiscussionAsync(int id, Discussion discussion)
        {
            var existingDiscussion = await _context.Discussions.FindAsync(id);

            if (existingDiscussion != null)
            {
                existingDiscussion.Name = discussion.Name;
                existingDiscussion.CreatedDate = discussion.CreatedDate;
                existingDiscussion.UserId = discussion.UserId;

                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteDiscussionAsync(int id)
        {
            var discussionToDelete = await _context.Discussions.FindAsync(id);

            if (discussionToDelete != null)
            {
                _context.Discussions.Remove(discussionToDelete);
                await _context.SaveChangesAsync();
            }
        }
    }
}
