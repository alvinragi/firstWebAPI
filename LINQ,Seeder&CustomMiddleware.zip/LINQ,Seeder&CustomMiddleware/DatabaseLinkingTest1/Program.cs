using DatabaseLinkingTest1.Data;
using DatabaseLinkingTest1.Services;
using Microsoft.EntityFrameworkCore;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle


builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Employee_API_CRUDContext")));


/*AppDbContext with a SQL Server database, fetching the connection string from the configuration settings named "Employee_API_CRUDContext". 
    Once this configuration is set up in the Startup class, AppDbContext can be injected into other parts of the application to interact 
    with the database using Entity Framework Core.*/

builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IDiscussionService, DiscussionService>();    //DI


builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseMiddleware<LoggingMiddleware>();     //custome middleware

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();