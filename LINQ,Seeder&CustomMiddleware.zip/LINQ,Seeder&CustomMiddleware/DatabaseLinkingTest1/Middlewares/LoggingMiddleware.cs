﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;

public class Startup    //configure application services and req processing pipeline
{
    public void ConfigureServices(IServiceCollection services)  //add services to DI container if any
    {
        // Add any services if needed
    }

    public void Configure(IApplicationBuilder app)  //to set up HTTP request processing pipeline
    {
        app.UseMiddleware<LoggingMiddleware>();

        // Other middleware and configurations
        app.UseRouting();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapGet("/", async context =>
            {
                await context.Response.WriteAsync("Hello from the main endpoint!");
            }); /*map a specific HTTP method and path("/") to a delegate that will handle the request.In this case, it responds with a simple
                message, "Hello from the main endpoint!"*/
        });
    }
}

public class LoggingMiddleware
{
    private readonly RequestDelegate _next;     //RequestDelegate Parameter

    public LoggingMiddleware(RequestDelegate next)  //constructor
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            // Log the request details
            string logMessage = $"{DateTime.Now} - {context.Request.Method} {context.Request.Path}";

            // Specify the path to the log file
            string filePath = "logfile.txt";

            // Use StreamWriter to write the log message to the file
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                await writer.WriteLineAsync(logMessage);
            }

            // Call the next middleware in the pipeline
            await _next(context);
        }
        catch (Exception ex)
        {
            // Log any exceptions that occur
            string errorMessage = $"{DateTime.Now} - Exception: {ex.Message}";
            Console.WriteLine(errorMessage);

            // Optionally, you can rethrow the exception
            throw;
        }
    }
}