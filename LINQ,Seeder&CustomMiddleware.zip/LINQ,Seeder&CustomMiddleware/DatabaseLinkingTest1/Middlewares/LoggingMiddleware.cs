﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;

public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        // Add any services if needed
    }

    public void Configure(IApplicationBuilder app)
    {
        app.UseMiddleware<LoggingMiddleware>();

        // Other middleware and configurations
        app.UseRouting();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapGet("/", async context =>
            {
                await context.Response.WriteAsync("Hello from the main endpoint!");
            });
        });
    }
}

public class LoggingMiddleware
{
    private readonly RequestDelegate _next;

    public LoggingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Log the request details
        string logMessage = $"{DateTime.Now} - {context.Request.Method} {context.Request.Path}";
        Console.WriteLine(logMessage);

        // Call the next middleware in the pipeline
        await _next(context);
    }
}