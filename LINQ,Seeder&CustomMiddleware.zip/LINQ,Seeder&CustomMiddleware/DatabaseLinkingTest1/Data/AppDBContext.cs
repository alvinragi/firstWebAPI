﻿using DatabaseLinkingTest1.Data;
using DatabaseLinkingTest1.Models;
using Microsoft.EntityFrameworkCore;

namespace DatabaseLinkingTest1.Data         //cs for interacting with database
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)     //constructors  //pass configuration options
        {
        }
        public DbSet<User> Users { get; set; }  //represent a collection of user entities from the database
        public DbSet<Discussion> Discussions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Call the base method first
            base.OnModelCreating(modelBuilder);

            // Define the foreign key relationship
            modelBuilder.Entity<Discussion>().HasOne(u => u.User);

            // Seed data
            SeedData(modelBuilder);
        }
        private static void SeedData(ModelBuilder modelBuilder)
        {
            // Seed Users
            modelBuilder.Entity<User>().HasData(
                new User { UserId = 1, Name = "Tootu Doe", Age = 30, Role = "Admin" },
                new User { UserId = 2, Name = "Jane Doe", Age = 25, Role = "User" }
            );

            // Seed Discussions
            modelBuilder.Entity<Discussion>().HasData(
                new Discussion { DiscussionID = 1, Name = "Discussion 1", CreatedDate = DateTime.Now, UserId = 1 },
                new Discussion { DiscussionID = 2, Name = "Discussion 2", CreatedDate = DateTime.Now, UserId = 2 }
            );
        }
    }
}


/*AppDbContext serves as the bridge between your application and the database, providing access to entities (such as User) 
 * through properties like Users.
 
The DbContextOptions passed to the constructor typically contain database connection information and other configurations needed 
by Entity Framework Core to connect to and interact with the database.

DbSet<User> represents a collection of User entities, allowing CRUD (Create, Read, Update, Delete) operations to be performed on the 
User table or collection in the connected database.

With this setup, Entity Framework Core will use AppDbContext to create, query, update, and delete User entities in the associated 
database based on the configured DbContextOptions and entity mappings.*/