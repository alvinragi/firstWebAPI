﻿namespace Authe_Autho.Models.Entity__data_passed_
{
    public class Role
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
    }
}
