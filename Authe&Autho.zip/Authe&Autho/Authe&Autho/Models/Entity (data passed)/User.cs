﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Authe_Autho.Models.Entity__data_passed_
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid UserID { get; set; }
        public string UserName { get; set; }

        public int UserCredentialID { get; set; }

        [ForeignKey("UserCredentialID")]

        [JsonIgnore]
        public UserCredential? UserCredential { get; set; }
    }
}
