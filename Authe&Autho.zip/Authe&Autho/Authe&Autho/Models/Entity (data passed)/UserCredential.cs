﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.InteropServices;
using System.Text.Json.Serialization;

namespace Authe_Autho.Models.Entity__data_passed_
{
    public class UserCredential
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserCredentialID { get; set; }
        public string UserMail { get; set; }
        public string UserPassword { get; set; }
        public int RoleID { get; set; }

        [JsonIgnore]
        public User User { get; set; }

        [ForeignKey("RoleID")]

        [JsonIgnore]
        public Role Role { get; set; }

    }
}
