﻿using System.ComponentModel.DataAnnotations;

namespace Authe_Autho.Models.API__data_from_req_
{
    public class Login
    {
        [Required(ErrorMessage = "UserMail is required.")]
        public string UserMail { get; set; }

        [Required(ErrorMessage = "UserMail is required.")]
        public string UserPassword { get; set; }
    }
}
