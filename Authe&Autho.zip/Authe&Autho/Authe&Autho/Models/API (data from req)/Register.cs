﻿using System.ComponentModel.DataAnnotations;

namespace Authe_Autho.Models.API__data_from_req_
{
    public class Register
    {
        [Required(ErrorMessage = "Name is required")]                           //validation
        [MaxLength(50, ErrorMessage = "Name cannot exceed 50 characters")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [MaxLength(50, ErrorMessage = "Email cannot exceed 50 characters")]
        public string UserMail { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [MinLength(3, ErrorMessage = "password must be at lease 6 characters")]
        public string UserPassword { get; set; }
        public int RoleID { get; set; } = 1;
    }
}
