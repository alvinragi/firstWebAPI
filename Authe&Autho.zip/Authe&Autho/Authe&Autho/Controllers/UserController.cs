﻿using Authe_Autho.Services;
using Microsoft.AspNetCore.Mvc;
using Authe_Autho.Models.API__data_from_req_;

namespace Authe_Autho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("register")]      //register is route template
        //associated controller action will be invoked when an HTTP POST request is made to the specific URL route "register."
        public async Task<IActionResult> RegisterUser([FromBody] Register newRegisteredUser)
        {
            bool userAdded = await _userService.RegisterUserAsync(newRegisteredUser);

            if (userAdded)
            {
                return Ok("User added successfully.");
            }
            return Conflict("Failed to add user.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> LoginUser([FromBody] Login loginUser)
        {
            string ExistingUserToken = await _userService.LoginUserAsync(loginUser);

            if (ExistingUserToken != null)
            {
                return Ok(ExistingUserToken);
            }
            return Conflict("Failed to Log in user.");
        }


    }
}
