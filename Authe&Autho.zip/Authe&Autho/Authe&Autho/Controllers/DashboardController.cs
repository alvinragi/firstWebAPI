﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Authe_Autho.Controllers
{
    [Authorize("User")]    // Requires authentication for access
    [Route("api/[controller]")]
    [ApiController]
    public class DashBoardController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Welcome to OOTY, Nice to meet you!, User");
        }
    }
}