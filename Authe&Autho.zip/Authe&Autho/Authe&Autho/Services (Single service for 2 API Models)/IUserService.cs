﻿using Authe_Autho.Models.API__data_from_req_;


namespace Authe_Autho.Services
{
    public interface IUserService
    {
        Task<bool> RegisterUserAsync(Register newRegisteredUser);

        Task<string> LoginUserAsync(Login userLogin);
    }
}      