﻿using Authe_Autho.Data;
using Authe_Autho.Models.API__data_from_req_;
using Authe_Autho.Models.Entity__data_passed_;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace Authe_Autho.Services
{
    public class UserService : IUserService
    {
        private readonly AppDBContext _context;
        private IConfiguration _config;
        public UserService(AppDBContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        public async Task<bool> RegisterUserAsync(Register newRegisteredUser)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {

                    var userCredential = new UserCredential
                    {
                        UserMail = newRegisteredUser.UserMail,
                        UserPassword = HashPassword(newRegisteredUser.UserPassword),
                        RoleID = newRegisteredUser.RoleID
                    };

                    _context.UserCredential.Add(userCredential);
                    await _context.SaveChangesAsync();

                    var newUser = new User
                    {
                        UserName = newRegisteredUser.UserName,
                        UserCredentialID = userCredential.UserCredentialID
                    };

                    _context.User.Add(newUser);
                    await _context.SaveChangesAsync();

                    transaction.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    transaction.Rollback();
                    return false;
                }
            }
        }

        public async Task<string> LoginUserAsync(Login userLogin)
        {
            try
            {
                var userCredential = await _context.UserCredential.FirstOrDefaultAsync(u => u.UserMail == userLogin.UserMail);
                if (userCredential != null)
                {
                    if (string.Equals(HashPassword(userLogin.UserPassword), userCredential.UserPassword, StringComparison.Ordinal))
                    {
                        var userName = await (from userTable in _context.User
                                              join userCredTable in _context.UserCredential
                                              on userTable.UserCredentialID equals userCredential.UserCredentialID
                                              where userCredTable.UserMail == userLogin.UserMail
                                              select userTable.UserName)
                                               .FirstOrDefaultAsync();
                        string role = await GetRole(userCredential);
                        string tokengenerated = TokenGenerater(role);
                        return tokengenerated;
                    }
                    return null;
                }
                return null;
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
        private string TokenGenerater(string UserRole)
        {

            var authClaim = new Claim(ClaimTypes.Role, UserRole);
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var Sectoken = new JwtSecurityToken(_config["Jwt:Issuer"],
            _config["Jwt:Issuer"],
            claims: new List<Claim> { authClaim },
            expires: DateTime.Now.AddMinutes(120),
            signingCredentials: credentials);

            var token = new JwtSecurityTokenHandler().WriteToken(Sectoken);

            return token;
        }
        private async Task<string> GetRole(UserCredential user)
        {
            var roleObject = await _context.Role.FirstOrDefaultAsync(u => u.RoleID == user.RoleID);
            return roleObject?.RoleName;
        }
    }
}
