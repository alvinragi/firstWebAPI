﻿using Authe_Autho.Models.Entity__data_passed_;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace Authe_Autho.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {
        }

        public DbSet<UserCredential> UserCredential { get; set; }
        public DbSet<User> User { get; set; }
        public DbSet<Role> Role { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        //OnModelCreating method is a part of Entity Framework Core that allows you to configure how your entities (tables) are related to each other
        //in the database.
        {
            
            modelBuilder.Entity<User>()
                 .HasOne(u => u.UserCredential)
                 .WithOne(uc => uc.User)
                 .HasForeignKey<User>(u => u.UserCredentialID);
            
            modelBuilder.Entity<UserCredential>()
                .HasOne(uc => uc.Role)
                .WithMany()
                .HasForeignKey(uc => uc.RoleID);

            SeedData(modelBuilder);
            //Each user has one credential, and each credential points back to one user.
            //for this mention the user and usercredential in the other cs class
            //also add ignore
        }
        private void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasData(
         new Role { RoleID = 1, RoleName = "Admin" },
         new Role { RoleID = 2, RoleName = "User" }
         );
        }
    }
}
