﻿using JwtInDotnetCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Text;

namespace JwtInDotnetCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration _config;     //an interface to access appsettings.json . to get configuration settings like JWT key and issuer
        private readonly List<User> _users;
        public LoginController(IConfiguration config)
        {
            _config = config;
            _users = new List<User>         //list initialization
        {
            new User("user1", HashPassword("password1"), "user1@example.com", new List<string> {"User"}),
            new User("user2", HashPassword("password2"), "user2@example.com", new List<string> {"Admin"})
        };
        }

        [HttpPost]                                                          //handles HTTP POST requests to the specified route ("api/[controller]").
        public IActionResult Post([FromBody] LoginRequest loginRequest)     //Taking a LoginRequest object
                                                                            //From body tells modelbinder to bind data from request to loginRequest
        {
            //your logic for login process
            // Validate the model based on LoginRequest class

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);  ///details about the validation errors
            }

            // Find the user by username
            var user = _users.FirstOrDefault(u => u.UserName == loginRequest.username);

            // Check if the user exists and the password is correct
            if (user == null || !VerifyPassword(loginRequest.password, user.Password))
            {
                return Unauthorized("Invalid username or password.");
            }

            //If login usrename and password are correct then proceed to generate token

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            // retrieves a configuration value named "Jwt:Key" from the application configuration.
            //SymmetricSecurityKey expects a byte array as the key.

            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            //used to sign the JWT token, ensuring its integrity and authenticity.


            //Creates a new instance of JwtSecurityToken with the specified issuer, subject, expiration time, and signing credentials.
            var Sectoken = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);
            //null here is the place for subject for the token

            var token = new JwtSecurityTokenHandler().WriteToken(Sectoken);
            //token variable will contain the JWT token as a string. 

            return Ok(token);
        }

        private bool VerifyPassword(string enteredPassword, string hashedPassword)
        {
            // In a production environment, use a secure password hashing library (e.g., BCrypt)
            // For simplicity, we'll use a basic hashing method here for demonstration purposes
            return hashedPassword == HashPassword(enteredPassword);
        }

        private string HashPassword(string password)
        {
            // In a production environment, use a secure password hashing library (e.g., BCrypt)
            // For simplicity, we'll use a basic hashing method here for demonstration purposes
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }
}
