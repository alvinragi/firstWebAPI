﻿using RepositoryPattern.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using GenericRepositoryPattern.UnitOfWork.ForumCategoryService.Infrastructure.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RepositoryPattern.Models.EntityModel;
using RepositoryPattern.Models.APIModel;

namespace RepositoryPattern.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ForumcategoryController : ControllerBase
    {
        private readonly IForumCategoryService _forumService;

        public ForumcategoryController(IForumCategoryService forumcategoryService)
        {
            _forumService = forumcategoryService;
        }

        [HttpGet]
        public IActionResult GetForumCategory()
        {
            var forumCategories = _forumService.GetForumCategories();
            return Ok(forumCategories);
        }

        [HttpGet("{id}")]
        public IActionResult GetForumCategoryById(int id)
        {
            var forumCategory = _forumService.GetForumCategoryById(id);
            if (forumCategory == null)
            {
                return NotFound();
            }
            return Ok(forumCategory);
        }

        [HttpPost]
        public IActionResult AddForumCategory(ForumCategoryDto forumCategory)
        {
            _forumService.CreateForumCategory(forumCategory);
            return Ok("New Forum Category added successfully");
        }

        [HttpPut("{id}")]
        public IActionResult UpdateForumCategory(int id, ForumCategoryDto forumCategory)
        {
            if (id != forumCategory.ForumCategoryID)
            {
                return BadRequest();
            }

            _forumService.UpdateForumCategory(id, forumCategory);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteForumCategory(int id)
        {
            if (id != null)
            {
                _forumService.DeleteForumCategory(id);
                return NoContent();
            }

            return NotFound();
        }
    }
}
