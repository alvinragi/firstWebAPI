﻿using RepositoryPattern.Repositories;

namespace GenericRepositoryPattern.UnitOfWork
{
    namespace ForumCategoryService.Infrastructure.UnitOfWork
    {
        public interface IUnitOfWork
        {
            IForumCategoryRepository ForumCategory { get; }

            int Complete();
        }

    }

}