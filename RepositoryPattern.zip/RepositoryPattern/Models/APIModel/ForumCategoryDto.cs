﻿namespace RepositoryPattern.Models.APIModel
{
    public class ForumCategoryDto
    {
        public int ForumCategoryID { get; set; }
        public string ForumCategoryName { get; set; }

        public bool IsDeleted { get; set; }
    }
}