﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Numerics;
using System.Text.Json.Serialization;

namespace RepositoryPattern.Models.EntityModel
{
    public class ForumCategory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ForumCategoryID { get; set; }
        public string ForumCategoryName { get; set; }
        public bool IsDeleted { get; set; }
    }
}
