﻿namespace RepositoryPattern.Repositories
{
    using Models;
    using RepositoryPattern.Models.EntityModel;

    public interface IForumCategoryRepository : IRepository<ForumCategory>
    {
    }
}
