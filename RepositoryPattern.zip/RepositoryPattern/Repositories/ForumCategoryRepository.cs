﻿namespace RepositoryPattern.Repositories
{
    using Models;
    using RepositoryPattern.Data;
    using RepositoryPattern.Models.EntityModel;

    public class ForumCategoryRepository : Repository<ForumCategory>, IForumCategoryRepository
    {
        public ForumCategoryRepository(AppDbContext context) : base(context) { }
    }
}
