﻿namespace RepositoryPattern.Data
{
    using Microsoft.EntityFrameworkCore;
    using RepositoryPattern.Models.EntityModel;
    using System.Collections.Generic;
    using System.Reflection.Emit;

    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<ForumCategory> ForumCategories { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Your model configurations here...

            SeedData(modelBuilder);

            base.OnModelCreating(modelBuilder);
        }
        private static void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ForumCategory>().HasData(
                new ForumCategory { ForumCategoryID = 1, ForumCategoryName = ".NET"},
                new ForumCategory { ForumCategoryID = 2, ForumCategoryName = "Angular"}
            );

        }
    }
}
