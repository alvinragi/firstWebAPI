﻿using RepositoryPattern.Models.APIModel;
using RepositoryPattern.Models.EntityModel;
/*using RepositoryPattern.UnitOfWork.ForumCategoryService.Infrastructure.UnitOfWork;
*/using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RepositoryPattern.Services;
using GenericRepositoryPattern.UnitOfWork.ForumCategoryService.Infrastructure.UnitOfWork;

namespace GenericRepositoryPattern.Services
{
    // MyApiProject.Application.Services
    public class ForumCategoryService : IForumCategoryService
    {
        private readonly IUnitOfWork _unitOfWork;

        public ForumCategoryService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IEnumerable<ForumCategoryDto> GetForumCategories()
        {

            var forumCategory = _unitOfWork.ForumCategory.GetAll();
            return MapToForumCategoryDtoList(forumCategory);
        }

        public ForumCategoryDto GetForumCategoryById(int id)
        {
            var forumCategory = _unitOfWork.ForumCategory.GetById(id);
            return MapToForumCategoryDto(forumCategory);
        }

        public void CreateForumCategory(ForumCategoryDto forumCategoryDto)
        {
            var forumCategory = MapToForumCategory(forumCategoryDto);
            _unitOfWork.ForumCategory.Add(forumCategory);
            _unitOfWork.Complete();
        }

        public void UpdateForumCategory(int id, ForumCategoryDto forumCategoryDto)
        {
            var existingForumCategory = _unitOfWork.ForumCategory.GetById(id);

            if (existingForumCategory == null)
            {
                // Handle not found scenario
                return;
            }

            // Update properties based on employeeDto
            existingForumCategory.ForumCategoryName = forumCategoryDto.ForumCategoryName;
            existingForumCategory.IsDeleted = forumCategoryDto.IsDeleted;

            _unitOfWork.Complete();
        }

        public void DeleteForumCategory(int id)
        {
            var forumCategory = _unitOfWork.ForumCategory.GetById(id);

            if (forumCategory == null)
            {
                // Handle not found scenario
                return;
            }

            _unitOfWork.ForumCategory.Delete(forumCategory);
            _unitOfWork.Complete();
        }

        private ForumCategoryDto MapToForumCategoryDto(ForumCategory forumCategory)
        {
            return new ForumCategoryDto
            {
                ForumCategoryID = forumCategory.ForumCategoryID,
                ForumCategoryName = forumCategory.ForumCategoryName,
                IsDeleted = forumCategory.IsDeleted
            };
        }

        private IEnumerable<ForumCategoryDto> MapToForumCategoryDtoList(IEnumerable<ForumCategory> employees)
        {
            return employees.Select(MapToForumCategoryDto);
        }

        private ForumCategory MapToForumCategory(ForumCategoryDto forumCategoryDto)
        {
            return new ForumCategory
            {
                ForumCategoryID = forumCategoryDto.ForumCategoryID,
                ForumCategoryName = forumCategoryDto.ForumCategoryName,
                IsDeleted = forumCategoryDto.IsDeleted
            };
        }

    }

}