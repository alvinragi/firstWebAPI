﻿using RepositoryPattern.Models.APIModel;
using RepositoryPattern.Models.EntityModel;

namespace RepositoryPattern.Services
{
    public interface IForumCategoryService
    {
        IEnumerable<ForumCategoryDto> GetForumCategories();
        ForumCategoryDto GetForumCategoryById(int id);
        void CreateForumCategory(ForumCategoryDto forumCategoryDto);
        void UpdateForumCategory(int id, ForumCategoryDto forumCategoryDto);
        void DeleteForumCategory(int id);
    }
}
