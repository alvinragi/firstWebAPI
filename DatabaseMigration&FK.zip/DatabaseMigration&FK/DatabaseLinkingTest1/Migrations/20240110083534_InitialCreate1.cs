﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DatabaseLinkingTest1.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Discussion_ID",
                table: "Users",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Discussion_ID1",
                table: "Users",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Discussions",
                columns: table => new
                {
                    Discussion_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Discussions", x => x.Discussion_ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Users_Discussion_ID1",
                table: "Users",
                column: "Discussion_ID1");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Discussions_Discussion_ID1",
                table: "Users",
                column: "Discussion_ID1",
                principalTable: "Discussions",
                principalColumn: "Discussion_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Discussions_Discussion_ID1",
                table: "Users");

            migrationBuilder.DropTable(
                name: "Discussions");

            migrationBuilder.DropIndex(
                name: "IX_Users_Discussion_ID1",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Discussion_ID",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Discussion_ID1",
                table: "Users");
        }
    }
}
