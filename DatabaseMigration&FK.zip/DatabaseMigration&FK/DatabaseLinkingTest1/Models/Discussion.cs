﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DatabaseLinkingTest1.Models
{
    public class Discussion
    {
        [Key]               //for defining the primary key thott below
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]   //for primary keys
        public int Discussion_ID { get; set; }
        public string? Name { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}
