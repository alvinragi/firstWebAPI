﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DatabaseLinkingTest1.Models
{
    public class User
    {
        [Key]               //for defining the primary key thott below
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int User_Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Role { get; set; }

        public int Discussion_ID { get; set; }           //Foreign Key        
        public Discussion? Discussion { get; set; }              //Navigation Property

    }
}
