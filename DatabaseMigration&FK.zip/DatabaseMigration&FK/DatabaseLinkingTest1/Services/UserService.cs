﻿using DatabaseLinkingTest1.Models;
using DatabaseLinkingTest1.Data;
using Microsoft.EntityFrameworkCore;

namespace DatabaseLinkingTest1.Services
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _context; //injecting an instance of AppDbContext

        public UserService(AppDbContext context)        //constructor of UserService class
        {
            _context = context;
        }
        /*By using constructor injection in this manner, the UserService class can utilize the AppDbContext instance(_context) to interact with the 
        database using Entity Framework Core.*/

        public async Task<IEnumerable<User>> GetUsersAsync()
        {
            return _context.Users.Include(u => u.Discussion).ToList(); // LAZY LOADING. to include the table values of discussion which is mapped.
        }

        public async Task<User> GetUserByIdAsync(int id)
        {
            return _context.Users.Find(id);
        }

        public async Task AddUserAsync(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public async Task UpdateUserAsync(int id, User user)
        {
            var existingEmployee = _context.Users.Find(user.User_Id);

            if (existingEmployee != null)
            {
                // Update properties of the existing employee
                existingEmployee.Name = user.Name;
                existingEmployee.Age = user.Age;
                existingEmployee.Role = user.Role;
                _context.SaveChanges();
            }
        }

        public async Task DeleteUserAsync(int id)
        {
            var employeeToDelete = _context.Users.Find(id);

            if (employeeToDelete != null)
            {
                _context.Users.Remove(employeeToDelete);
                _context.SaveChanges();
            }
        }
    }
}

